import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//Routing
import { PluginsRoutingModule } from './plugins-routing.module';

@NgModule({
  imports: [
    PluginsRoutingModule
  ],
  declarations: []
})
export class PluginsModule { }
