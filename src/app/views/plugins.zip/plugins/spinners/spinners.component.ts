import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  templateUrl: 'spinners.component.html',
  styleUrls: ['../../../../../node_modules/spinkit/css/spinkit.css'],
  encapsulation: ViewEncapsulation.None
})
export class SpinnersComponent { }
